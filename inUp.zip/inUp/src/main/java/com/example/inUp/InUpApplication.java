package com.example.inUp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InUpApplication {

	public static void main(String[] args) {
		SpringApplication.run(InUpApplication.class, args);
	}

}
