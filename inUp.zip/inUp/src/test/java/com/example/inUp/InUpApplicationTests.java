package com.example.inUp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InUpApplicationTests {

	@Test
	void contextLoads() {
	}

}
